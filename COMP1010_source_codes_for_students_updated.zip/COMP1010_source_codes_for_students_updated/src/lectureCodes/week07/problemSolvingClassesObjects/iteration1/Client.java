package lectureCodes.week07.problemSolvingClassesObjects.iteration1;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Deck pack = new Deck();
		//System.out.println(pack);
		pack.shuffle(1000);
		System.out.println(pack);
	}

}
