package practicalClassCodes.week05;
public class Date {
	public int date, month, year;
}
