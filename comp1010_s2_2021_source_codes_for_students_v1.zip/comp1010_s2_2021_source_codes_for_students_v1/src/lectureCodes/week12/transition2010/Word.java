package lectureCodes.week12.transition2010;

public class Word {
	public String data;
	public WordType type;
	
	public Word(String d, WordType t) {
		data = d;
		type = t;
	}
	
	public String toString() {
		return data;
	}
	
}
