package lectureCodes.week04.classesObjects2.fullExample;

public class Squad {
	public Player[] players;
}
