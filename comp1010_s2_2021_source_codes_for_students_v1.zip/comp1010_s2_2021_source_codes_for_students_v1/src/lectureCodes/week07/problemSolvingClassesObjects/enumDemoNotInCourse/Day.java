package lectureCodes.week07.problemSolvingClassesObjects.enumDemoNotInCourse;

public enum Day {
    SUNDAY, 
    MONDAY, 
    TUESDAY, 
    WEDNESDAY,
    THURSDAY, 
    FRIDAY, 
    SATURDAY 
}
