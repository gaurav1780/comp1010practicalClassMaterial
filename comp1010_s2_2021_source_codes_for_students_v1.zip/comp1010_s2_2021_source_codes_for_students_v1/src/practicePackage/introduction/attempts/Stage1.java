package practicePackage.introduction.attempts;

public class Stage1 {
	/**
	 * 
	 * @param n
	 * @return square of n
	 */
	public int square(int n) {
		return 0; //to be completed
	}

	/**
	 * 
	 * @param n
	 * @return the cube of n
	 */
	public int cube(int n) {
		return 0; //to be completed
	}
	
	public double average(double a, double b) {
		return 0; //to be completed
	}
	
	/**
	 * 
	 * @param n (assume n >= 0)
	 * @return the last digit of the number n
	 */
	public int lastDigit(int n) {
		return 0; //to be completed
	}

	/**
	 * 
	 * @param n
	 * @return true if n is positive (more than 0), false otherwise
	 */
	public boolean isPositive(int n) {
		return false; //to be completed
	}	

	/**
	 * 
	 * @param n
	 * @return true if n is even (divisible by 2), false otherwise
	 */
	public boolean isEven(int n) {
		return false; //to be completed
	}

	/**
	 * 
	 * @param a
	 * @param b
	 * @return higher of the two integers passed
	 */
	public int higher(int a, int b) {
		if(a>b) {
			return a;
		}
		else {
			return b;
		}
	}
	
	public static void main(String[] args) {
		System.out.println("higher of 2 and 3: "+new Stage1().higher(2, 3));
	}
	
	/**
	 * assumption: one of the two values passed is even, other is odd
	 * 
	 * @param a
	 * @param b
	 * @return the value that is even
	 */
	public int evenOne(int a, int b) {
		return 0; //to be completed
	}

	/**
	 * 
	 * @param n
	 * @param low
	 * @param high (assume low is less than or equal to high)
	 * @return true if n is in the range [low...high], false otherwise
	 */
	public boolean isInRange(int n, int low, int high) {
		return false; //to be completed
	}

	/**
	 * DO NOT use Math library
	 * @param a
	 * @param b
	 * @param c
	 * @return the highest of the three integers passed
	 */
	public int highest(int a, int b, int c) {
		return 0; //to be completed
	}
}
