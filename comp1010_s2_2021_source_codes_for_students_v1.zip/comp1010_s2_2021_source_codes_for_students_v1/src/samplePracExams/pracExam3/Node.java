package samplePracExams.pracExam3;

public class Node {
	public Node next;
	public int data;

	public Node(int d, Node n) {
		data = d;
		next = n;
	}
}
