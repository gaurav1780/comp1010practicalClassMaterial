public class Car {
	public String model;
	public int price;
}