package practicePackage._01_introduction.attempts;

/**
 * IMPORTANT: Tests are NOT provided for this section, 
 * and neither are function headers.
 * Only function names are provided. 
 * You are meant to write the functions 
 * from scratch using other  
 * @author gauravgupta
 *
 */
public class startFromScratch {
	/**
	 * Define a function 
	 */
}
