package practicePackage._06_sorting.attempts;

public class Stage1 {
	/**
	 * @param data
	 * @param idx1
	 * @param idx2
	 * @return the array after the items at idx1 and idx2 are swapped. If either
	 *         indices are invalid, return null.
	 */
	public static int[] swap(int[] data, int idx1, int idx2) {
		return null; //to be completed
	}

	/**
	 * 
	 * @param data
	 * @return the first index of where data isn't sorted in ascending order. If
	 *         data is sorted, return the length of the array. For example {10, 20,
	 *         90, 5, 70} would return 3 (90 > 5). If data is invalid, return -1;
	 */
	public static int partSorted(int[] data) {
		return -1; //to be completed
	}

	/**
	 * 
	 * @param data
	 * @return true if the sorted array contains any duplicates, false otherwise.
	 */
	public static boolean duplicates(int[] data) {
		return false; //to be completed
	}
}
