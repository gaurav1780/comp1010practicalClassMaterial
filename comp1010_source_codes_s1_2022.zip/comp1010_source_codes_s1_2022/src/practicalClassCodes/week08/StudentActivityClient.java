package practicalClassCodes.week08;

public class StudentActivityClient {

	public static void main(String[] args) {
		//student activity 1
		
		//student activity 2
		
		//student activity 3	
		
		//student activity 4	
		
		//student activity 5	
		
		//student activity 6	
		
		//student activity 7	
		
		//student activity 8
		
		//student activity 9	
		
		//student activity 10
	}

}
