package lectureCodes.week10_11.linkedList;

public class MyLinkedListClient {

	public static void main(String[] args) {
		MyLinkedList list = new MyLinkedList();
		list.add("you?");
		list.add("are");
		list.add("how");
		list.add("hello,");
		System.out.println(list);
	}

}
