package lectureCodes.week05_06.recursion;

public class FibClient {
	public static void main(String[] args) {
		System.out.println(RecursionService.fastFibonacci(43));
	}
}
