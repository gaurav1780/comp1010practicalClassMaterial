

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class Question11 {
	/**
	 * You cannot use Math library
	 * @param val
	 * @return floor of val
	 * floor of a floating-point value is defined as the highest integer
	 * that is less than or equal to the value.
	 * For example, floor(4.2) = 4, floor(7.0) = 7,
	 * floor(5.9999) = 5, floor(-3.7) = -4
	 */
	public static int floor(double val) {
		return 0; 
	}
	
	@Test
	void testFloor() {
		assertEquals(1, floor(1.99));
		assertEquals(0, floor(0.75));
		assertEquals(7, floor(7.00));
		assertEquals(5, floor(5.9999));
		assertEquals(-4, floor(-3.7));
		assertEquals(400, floor(400.001));
		assertEquals(-500, floor(-499.99999));
	}
}
