

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class Question10 {
	/**
	 * 
	 * @param x
	 * @param y
	 * @return the quadrant in which coordinate (x, y) exists
	 * quadrant 1: non-negative x, non-negative y
	 * quadrant 2: negative x, non-negative y
	 * quadrant 3: negative x, negative y
	 * quadrant 4: non-negative x, negative y
	 * 
	 */
	public static int getQuandrant(int x, int y) {
		return 0; //to be completed
	}
	
	@Test
	//which quandrant would 0,0 be?
	
	void testGetQuandrant() {
		assertEquals(1, getQuandrant(2,2));
		assertEquals(2, getQuandrant(-2,3));
		assertEquals(3, getQuandrant(-3,-4));
		assertEquals(4, getQuandrant(3,-3));
	}
}
