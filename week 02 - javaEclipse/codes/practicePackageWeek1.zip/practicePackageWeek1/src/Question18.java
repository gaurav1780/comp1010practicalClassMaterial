

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class Question18 {
	/**
	 * two integers (a and b) are said to be co-prime if they have no
	 * common divisor (other than 1). 
	 * so 16 and 21 are co-prime but 18 and 21 are not
	 * (since they are both divisible by 3).
	 * @param a
	 * @param b
	 * @return true if a and b are co-prime, false otherwise
	 */
	public static boolean areCoPrime(int a, int b) {
		return false; //to be completed
	}
	
	@Test
	void testAreCoPrime() {
		assertTrue(areCoPrime(77, 65));
		assertTrue(areCoPrime(720, 143));
		assertTrue(areCoPrime(256, 729));
		assertFalse(areCoPrime(143, 77));
		assertFalse(areCoPrime(160, 405));
		assertFalse(areCoPrime(1000000, 10000000));
	}
}
