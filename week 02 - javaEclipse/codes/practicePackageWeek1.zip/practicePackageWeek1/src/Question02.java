

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class Question02 {
	public static boolean isPositive(int n) {
		return false;
	}
	
	@Test
	void testIsPositive() {
		assertTrue(isPositive(6));
		assertFalse(isPositive(-12));
		assertFalse(isPositive(0));
		assertTrue(isPositive(10000000));
		assertTrue(isPositive(7));
		assertFalse(isPositive(-911));
		assertTrue(isPositive(1010101));
	}
}
