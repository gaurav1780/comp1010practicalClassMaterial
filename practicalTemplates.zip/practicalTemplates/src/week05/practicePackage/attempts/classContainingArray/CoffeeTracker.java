package week05.practicePackage.attempts.classContainingArray;

public class CoffeeTracker {
	public int[] coffeesPerDay;

	/**
	 * create an instance copy of data into coffeesPerDay. The two
	 * objects, data and coffeesPerDay, should have the same values but
	 * NOT refer to the same instance.
	 * @param data (you may assume data.length > 0)
	 */
	public CoffeeTracker(int[] data) {
		//to be completed
	}

	public int coffeesConsumed() {
		return 0; //to be completed
	}

	public double averageCoffeesConsumed() {
		return 0; //to be completed
	}

	public int coffeeFreeDays() {
		return 0; //to be completed
	}
}
