package week05.practical;
public class Person {
	public String name;
	public int age;
}