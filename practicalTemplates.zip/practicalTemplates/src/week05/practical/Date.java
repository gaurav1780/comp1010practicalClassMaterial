package week05.practical;
public class Date {
	public int date, month, year;
}