package week05.practical;
public class Car {
	public String model;
	public int price;
}