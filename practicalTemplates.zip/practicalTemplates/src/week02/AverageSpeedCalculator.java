package week02;

public class AverageSpeedCalculator {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		double distanceAB = 50;
		double speedAToB = 20; //20 kmph
		double speedBToA = 12.5; //12.5 kmph

		//complete the following steps
		double timeAToB = 0; //calculate time from a to b
		double timeBToA = 0; //calculate time from b to a
		double totalReturnTripTimeTaken = 0; //calculate total time taken
		double totalReturnTripDistance = 0; //total distance travelled
		double averageSpeed = 0; //calculate average speed
		System.out.println(averageSpeed);
	}

}
