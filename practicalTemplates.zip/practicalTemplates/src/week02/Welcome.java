package week02;

public class Welcome {

	public static void main(String[] args) {
		System.out.println("Welcome to COMP125!");
	}

}
