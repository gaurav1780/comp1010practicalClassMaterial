package week02;
public class MyFirstProgram {
	public static void main(String[] args) {
		System.out.println("My first Java program - woot!");
	}
}