package week02;

public class SpeedCalculator {

	public static void main(String[] args) {
		double distance = 24.72;
		double time = 2.4;
		double speed = distance/time;
		System.out.println("Distance: "+distance+" km, Time: "+time+" hours, Speed: "+speed+" kmph");
	}

}
