public class Person {
	public String name;
	public int age;
}