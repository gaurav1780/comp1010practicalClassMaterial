public class Date {
	public int date, month, year;
}