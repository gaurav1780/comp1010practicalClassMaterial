package week9hurdleTemplate;

import java.util.ArrayList;

/**
 * 
 * @author gauravgupta (functions), Emilie Hyslop (tests)
 * Contains 15 functions that operate on lists of lists 
 * (all except countSquares operate on list of lists of Integer objects,
 * whereas countSquares operates on list of lists of Rectangle objects)
 * 
 *   Each method except getClean has two tests 
 *   - Basic tests: assume none of the sublists are null, and none of the items
 *   within the sublists are null.
 *   - Advanced tests: make no such assumption
 */
public class ListOfListService {

	/**
	 * 
	 * @param list
	 * @return the first item of the first sub-list in the list, if any. return null
	 *         otherwise
	 */
	public static Integer getFirstItem(ArrayList<ArrayList<Integer>> list) {
		return 0;
	}

	/**
	 * 
	 * @param list
	 * @param i
	 * @return true if sub-list at index i (if any) is NOT null, false otherwise
	 */
	public static boolean isSubListNotNull(ArrayList<ArrayList<Integer>> list, int i) {
		return false;
	}

	/**
	 * 
	 * @param list
	 * @param i
	 * @param k
	 * @return the item at index k inside the sub-list at index i. return null if
	 *         such an item doesn't exist
	 */
	public static Integer getItem(ArrayList<ArrayList<Integer>> list, int i, int k) {
		return 0;
	}

	/**
	 * 
	 * @param list
	 * @param target: assume not null
	 * @return true if the list contains the given item, false otherwise
	 */
	public static boolean contains(ArrayList<ArrayList<Integer>> list, Integer target) {
		return false;
	}

	/**
	 * 
	 * @param list
	 * @return the last item in the list. One or many of the sub-lists may
	 *         be null or empty. if there are zero items in the list, return null.
	 *         Note if the actual item is null, return null anyway. For example, in
	 *         [[10,20], [40,null]] For basic test, you may assume, neither the list
	 *         or any sublist or any item in the sub-lists is null
	 */
	public static Integer getLastItem(ArrayList<ArrayList<Integer>> list) {
		return 0;
	}

	/**
	 * 
	 * @param list
	 * @param i
	 * @return number of items in sub-list at index i, if any. Return 0 otherwise
	 */
	public static int sizeOf(ArrayList<ArrayList<Integer>> list, int i) {
		return 0;
	}

	/**
	 * 
	 * @param list
	 * @return the total number of Integer items in the list. for basic version,
	 *         return total number of Integer items (including null). For advanced
	 *         version, return number of non-null Integer items.
	 */
	public static int countItems(ArrayList<ArrayList<Integer>> list) {
		return 0;
	}
	
	/**
	 * 
	 * @param list
	 * @return number of rectangles in the list that are squares
	 */
	public static int countSquares(ArrayList<ArrayList<Rectangle>> list) {
		return 0;
	}
	
	/**
	 * 
	 * @param list
	 * @return the sum of of all non-null Integer items in the list.
	 */
	public static int sumItems(ArrayList<ArrayList<Integer>> list) {
		return 0;
	}

	/**
	 * 
	 * @param list
	 * @param i
	 * @return true if sub-list at index i, if any, is in ascending order (each item
	 *         is less than or equal to the next item); and false otherwise.
	 */ 
	public static boolean isAscending(ArrayList<ArrayList<Integer>> list, int i) {
		return false;
	}

	/**
	 * 
	 * @param list
	 * @return true if each sub-list is individually in ascending order, false
	 *         otherwise.
	 */
	public static boolean allSubListsAscending(ArrayList<ArrayList<Integer>> list) {
		return false;
	}

	/**
	 * 
	 * @param list
	 * @return true if each sub-list is non-null and of the same size. return null
	 *         if list is null or any sub-list is null.
	 */
	public static boolean allSubListsSameSize(ArrayList<ArrayList<Integer>> list) {
		return false;
	}

	/**
	 * 
	 * @param list
	 * @return the list of list converted to a list, excluding any null items. Items
	 *         should occur in the order they appear in the list.
	 */
	public static ArrayList<Integer> nonNullItemsToList(ArrayList<ArrayList<Integer>> list) {
		return new ArrayList<Integer>();
	}

	/**
	 * 
	 * @param list
	 * @return the list of list converted to an array, excluding any null items.
	 *         Items should occur in the order they appear in the list.
	 */
	public static int[] nonNullItemsToArray(ArrayList<ArrayList<Integer>> list) {
		return new int[0];
	}
	
	/**
     * 
     * @param list
     * @return arraylist with null-sublists removed, and null items from non-null sub-lists removed.
     * return an empty arraylist if list is null
     */
    public static ArrayList<ArrayList<Integer>> getClean(ArrayList<ArrayList<Integer>> list) {
        return new ArrayList<ArrayList<Integer>>();
    }
}
