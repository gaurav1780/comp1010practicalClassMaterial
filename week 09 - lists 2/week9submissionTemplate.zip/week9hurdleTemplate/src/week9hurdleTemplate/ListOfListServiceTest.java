package week9hurdleTemplate;

//import java.io.File;
//import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.Assert.*;
import org.junit.jupiter.api.*;

public class ListOfListServiceTest {
	ArrayList<ArrayList<Integer>> emptyList;
	ArrayList<ArrayList<Integer>> oneRow;
	ArrayList<ArrayList<Integer>> listSameSize;
	ArrayList<ArrayList<Integer>> list1;
	ArrayList<ArrayList<Integer>> list2;
	ArrayList<ArrayList<Integer>> list3_emptySubLists;
	ArrayList<ArrayList<Integer>> list4_nullItems;

	public static double score = 0;
	public static String result = "";
	public static String currentMethodName = null;
	ArrayList<String> methodsPassed = new ArrayList<String>();
	
	@BeforeEach
	public void createLists() {
		emptyList = new ArrayList<ArrayList<Integer>>();
		oneRow = new ArrayList<ArrayList<Integer>>();
		oneRow.add(new ArrayList<Integer>(Arrays.asList(10, 70, 20, 90)));

		listSameSize = new ArrayList<ArrayList<Integer>>();
		listSameSize.add(new ArrayList<Integer>(Arrays.asList(10, 70, 20, 90)));
		listSameSize.add(new ArrayList<Integer>(Arrays.asList(100, 700, 200, 900)));
		listSameSize.add(new ArrayList<Integer>(Arrays.asList(9, 8, 7, 6)));
		listSameSize.add(new ArrayList<Integer>(Arrays.asList(20, 22, 24, 26)));

		list1 = new ArrayList<ArrayList<Integer>>();
		list1.add(new ArrayList<Integer>(Arrays.asList(9, 8, 7, 6, 5, 4, -1, -2)));
		list1.add(new ArrayList<Integer>(Arrays.asList(100, 200, 700, 900)));
		list1.add(new ArrayList<Integer>(Arrays.asList(10, 70, 20, 90, 30, 80)));
		list1.add(new ArrayList<Integer>(Arrays.asList(20, 22)));

		list2 = new ArrayList<ArrayList<Integer>>();
		list2.add(new ArrayList<Integer>(Arrays.asList(20, 22)));
		list2.add(new ArrayList<Integer>(Arrays.asList(9, 8)));
		list2.add(new ArrayList<Integer>(Arrays.asList(100, 700, 200)));
		list2.add(new ArrayList<Integer>(Arrays.asList(10, 70)));
		list2.add(new ArrayList<Integer>(Arrays.asList(20, 90)));
		list2.add(new ArrayList<Integer>(Arrays.asList(24, 26)));

		list3_emptySubLists = new ArrayList<ArrayList<Integer>>();
		list3_emptySubLists.add(new ArrayList<Integer>());
		list3_emptySubLists.add(new ArrayList<Integer>(Arrays.asList(9, 8, 7, 6, 5, 4, -1, -2)));
		list3_emptySubLists.add(new ArrayList<Integer>(Arrays.asList(10, 70, 20, 90, 30, 80)));
		list3_emptySubLists.add(new ArrayList<Integer>());
		list3_emptySubLists.add(new ArrayList<Integer>(Arrays.asList(20, 22)));
		list3_emptySubLists.add(new ArrayList<Integer>());

		list4_nullItems = new ArrayList<ArrayList<Integer>>();
		list4_nullItems.add(null);
		list4_nullItems.add(new ArrayList<Integer>(Arrays.asList(-1, -2, -1, 4, 5, 6, 7, 8, 9)));
		list4_nullItems.add(new ArrayList<Integer>(Arrays.asList(100, 200, 700, 900)));
		list4_nullItems.add(new ArrayList<Integer>(Arrays.asList(10, null, 20, 90)));
		list4_nullItems.add(null);
		list4_nullItems.add(new ArrayList<Integer>(Arrays.asList(20, 22, null)));
		list4_nullItems.add(null);
		list4_nullItems.add(null);
		list4_nullItems.add(null);
		
		currentMethodName = null;
	}

	@Test @Graded(description="GetFirstItemBasic", marks=4)
	public void testGetFirstItemBasic() {
		assertEquals(null, ListOfListService.getFirstItem(emptyList));
		assertEquals(Integer.valueOf(10), ListOfListService.getFirstItem(oneRow));
		assertEquals(Integer.valueOf(10), ListOfListService.getFirstItem(listSameSize));
		assertEquals(Integer.valueOf(9), ListOfListService.getFirstItem(list1));
		assertEquals(Integer.valueOf(20), ListOfListService.getFirstItem(list2));
		assertEquals(null, ListOfListService.getFirstItem(list3_emptySubLists));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="GetFirstItemComprehensive", marks=4)
	public void testGetFirstItemComprehensive() {
		testGetFirstItemBasic();
		assertEquals(null, ListOfListService.getFirstItem(null));
		assertEquals(null, ListOfListService.getFirstItem(list4_nullItems));

		list4_nullItems.set(0, new ArrayList<Integer>(Arrays.asList(5)));
		assertEquals(Integer.valueOf(5), ListOfListService.getFirstItem(list4_nullItems));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="IsSubListNotNullBasic", marks=4)
	public void testIsSubListNotNullBasic() {
		assertFalse(ListOfListService.isSubListNotNull(emptyList, 0));
		assertTrue(ListOfListService.isSubListNotNull(oneRow, 0));
		assertFalse(ListOfListService.isSubListNotNull(oneRow, -1));
		assertFalse(ListOfListService.isSubListNotNull(oneRow, 1));

		assertTrue(ListOfListService.isSubListNotNull(list2, 1));
		assertTrue(ListOfListService.isSubListNotNull(list2, 5));
		assertFalse(ListOfListService.isSubListNotNull(list2, 6));
		assertFalse(ListOfListService.isSubListNotNull(list2, -100));
		assertFalse(ListOfListService.isSubListNotNull(list2, 100));

		assertTrue(ListOfListService.isSubListNotNull(list3_emptySubLists, 0));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="IsSubListNotNullComprehensive", marks=4)
	public void testIsSubListNotNullComprehensive() {
		testIsSubListNotNullBasic();
		assertFalse(ListOfListService.isSubListNotNull(null, 0));
		assertFalse(ListOfListService.isSubListNotNull(list4_nullItems, 4));
		assertTrue(ListOfListService.isSubListNotNull(list4_nullItems, 3));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="GetItemBasic", marks=4)
	public void testGetItemBasic() {
		assertEquals(null, ListOfListService.getItem(emptyList, 0, 2));

		assertEquals(Integer.valueOf(10), ListOfListService.getItem(listSameSize, 0, 0));
		assertEquals(Integer.valueOf(90), ListOfListService.getItem(listSameSize, 0, 3));
		assertEquals(Integer.valueOf(22), ListOfListService.getItem(listSameSize, 3, 1));

		assertEquals(Integer.valueOf(10), ListOfListService.getItem(oneRow, 0, 0));
		assertEquals(Integer.valueOf(90), ListOfListService.getItem(oneRow, 0, 3));
		assertEquals(null, ListOfListService.getItem(oneRow, 0, 4));
		assertEquals(null, ListOfListService.getItem(oneRow, 0, -1));
		assertEquals(null, ListOfListService.getItem(oneRow, -1, 0));
		assertEquals(null, ListOfListService.getItem(oneRow, 1, 0));

		assertEquals(Integer.valueOf(20), ListOfListService.getItem(list1, 3, 0));
		assertEquals(Integer.valueOf(70), ListOfListService.getItem(list1, 2, 1));
		assertEquals(Integer.valueOf(-2), ListOfListService.getItem(list1, 0, 7));

		assertEquals(Integer.valueOf(26), ListOfListService.getItem(list2, 5, 1));
		assertEquals(null, ListOfListService.getItem(list2, 6, 1));

		assertEquals(null, ListOfListService.getItem(list3_emptySubLists, 3, 0));
		assertEquals(Integer.valueOf(20), ListOfListService.getItem(list3_emptySubLists, 2, 2));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="GetItemComprehensive", marks=4)
	public void testGetItemComprehensive() {
		testGetItemBasic();
		assertEquals(null, ListOfListService.getItem(null, 0, 0));

		assertEquals(null, ListOfListService.getItem(list4_nullItems, 4, 4));
		assertEquals(null, ListOfListService.getItem(list4_nullItems, 3, 1));
		assertEquals(Integer.valueOf(20), ListOfListService.getItem(list4_nullItems, 3, 2));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="ContainsBasic", marks=4)
	public void testContainsBasic() {
		assertFalse(ListOfListService.contains(emptyList, Integer.valueOf(10)));

		assertTrue(ListOfListService.contains(oneRow, Integer.valueOf(10)));
		assertTrue(ListOfListService.contains(oneRow, Integer.valueOf(70)));
		assertTrue(ListOfListService.contains(oneRow, Integer.valueOf(20)));
		assertTrue(ListOfListService.contains(oneRow, Integer.valueOf(90)));
		assertFalse(ListOfListService.contains(oneRow, Integer.valueOf(100)));

		assertTrue(ListOfListService.contains(list1, Integer.valueOf(-2)));
		assertTrue(ListOfListService.contains(list1, Integer.valueOf(30)));
		assertTrue(ListOfListService.contains(list1, Integer.valueOf(22)));
		assertTrue(ListOfListService.contains(list1, Integer.valueOf(900)));
		assertFalse(ListOfListService.contains(list1, Integer.valueOf(-3)));
		assertFalse(ListOfListService.contains(list1, Integer.valueOf(11)));

		assertTrue(ListOfListService.contains(list3_emptySubLists, Integer.valueOf(10)));
		assertFalse(ListOfListService.contains(list3_emptySubLists, Integer.valueOf(-3)));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="ContainsComprehensive", marks=4)
	public void testContainsComprehensive() {
		testContainsBasic();
		assertFalse(ListOfListService.contains(null, Integer.valueOf(10)));

		assertTrue(ListOfListService.contains(list4_nullItems, Integer.valueOf(22)));
		assertFalse(ListOfListService.contains(list4_nullItems, Integer.valueOf(-3)));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="GetLastItemBasic", marks=4)
	public void testGetLastItemBasic() {
		assertEquals(null, ListOfListService.getLastItem(emptyList));
		assertEquals(Integer.valueOf(26), ListOfListService.getLastItem(listSameSize));
		assertEquals(Integer.valueOf(90), ListOfListService.getLastItem(oneRow));
		assertEquals(Integer.valueOf(22), ListOfListService.getLastItem(list1));
		assertEquals(Integer.valueOf(26), ListOfListService.getLastItem(list2));
		assertEquals(Integer.valueOf(22), ListOfListService.getLastItem(list3_emptySubLists));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="GetLastItemComprehensive", marks=4)
	public void testGetLastItemComprehensive() {
		testGetLastItemBasic();
		assertEquals(null, ListOfListService.getLastItem(null));
		assertEquals(null, ListOfListService.getLastItem(list4_nullItems));
		list4_nullItems.get(5).set(2, 24);
		assertEquals(Integer.valueOf(24), ListOfListService.getLastItem(list4_nullItems));

		ArrayList<ArrayList<Integer>> allEmptyOrNull = new ArrayList<ArrayList<Integer>>();
		allEmptyOrNull.add(null);
		allEmptyOrNull.add(new ArrayList<Integer>());
		allEmptyOrNull.add(null);
		allEmptyOrNull.add(new ArrayList<Integer>());
		assertEquals(null, ListOfListService.getLastItem(allEmptyOrNull));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="SizeOfBasic", marks=4)
	public void testSizeOfBasic() {
		assertEquals(0, ListOfListService.sizeOf(emptyList, 0));

		assertEquals(4, ListOfListService.sizeOf(oneRow, 0));
		assertEquals(0, ListOfListService.sizeOf(oneRow, -1));
		assertEquals(0, ListOfListService.sizeOf(oneRow, 1));

		assertEquals(8, ListOfListService.sizeOf(list1, 0));

		assertEquals(3, ListOfListService.sizeOf(list2, 2));
		assertEquals(2, ListOfListService.sizeOf(list2, 5));
		assertEquals(0, ListOfListService.sizeOf(list2, -100));
		assertEquals(0, ListOfListService.sizeOf(list2, 100));

		assertEquals(8, ListOfListService.sizeOf(list3_emptySubLists, 1));
		assertEquals(0, ListOfListService.sizeOf(list3_emptySubLists, 3));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="SizeOfComprehensive", marks=4)
	public void testSizeOfComprehensive() {
		testSizeOfBasic();
		assertEquals(0, ListOfListService.sizeOf(null, 0));

		assertEquals(3, ListOfListService.sizeOf(list4_nullItems, 5));
		assertEquals(0, ListOfListService.sizeOf(list4_nullItems, 6));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="CountItemsBasic", marks=4)
	public void testCountItemsBasic() {
		assertEquals(0, ListOfListService.countItems(emptyList));
		assertEquals(16, ListOfListService.countItems(listSameSize));
		assertEquals(4, ListOfListService.countItems(oneRow));
		assertEquals(20, ListOfListService.countItems(list1));
		assertEquals(13, ListOfListService.countItems(list2));
		assertEquals(16, ListOfListService.countItems(list3_emptySubLists));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}
	
	@Test @Graded(description="CountSquaresBasic", marks=4)
	public void testCountSquaresBasic() {
		ArrayList<Rectangle> a = new ArrayList<Rectangle>();
		ArrayList<Rectangle> b = new ArrayList<Rectangle>();
		ArrayList<Rectangle> c = new ArrayList<Rectangle>();
		ArrayList<Rectangle> d = new ArrayList<Rectangle>();
		ArrayList<ArrayList<Rectangle>> list = new ArrayList<ArrayList<Rectangle>>();
		list.add(a);
		list.add(b);
		list.add(c);
		list.add(d);
		for(int i=0; i < 100; i++) {
			a.add(new Rectangle(i, i+1));
			b.add(new Rectangle(i+1, i));
			c.add(new Rectangle(i, i+2));
			d.add(new Rectangle(i+2, i));
		}
		//no squares yet
		assertEquals(0, ListOfListService.countSquares(list));
		a.add(0, new Rectangle(10, 10));
		assertEquals(1, ListOfListService.countSquares(list));
		d.add(new Rectangle(20, 20));
		assertEquals(2, ListOfListService.countSquares(list));
		b.add((int)(Math.random()*b.size()), new Rectangle(30, 30));
		c.add((int)(Math.random()*c.size()), new Rectangle(30, 30));
		assertEquals(4, ListOfListService.countSquares(list));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}
	
	@Test @Graded(description="CountSquaresAdvanced", marks=2)
	public void testCountSquaresAdvanced() {
		ArrayList<ArrayList<Rectangle>> list = null;
		assertEquals(0, ListOfListService.countSquares(list));

		testCountSquaresBasic();
		ArrayList<Rectangle> a = new ArrayList<Rectangle>();
		ArrayList<Rectangle> b = null;
		ArrayList<Rectangle> c = new ArrayList<Rectangle>();
		ArrayList<Rectangle> d = new ArrayList<Rectangle>();
		list = new ArrayList<ArrayList<Rectangle>>();
		list.add(a);
		list.add(b);
		list.add(c);
		list.add(d);
		for(int i=0; i < 100; i++) { //some null objects
			if(Math.random() < 0.9)
				a.add(new Rectangle(i, i+1));
			if(Math.random() < 0.9)
				c.add(new Rectangle(i, i+2));
			if(Math.random() < 0.9)
				d.add(new Rectangle(i+2, i));
		}
		//no squares yet
		assertEquals(0, ListOfListService.countSquares(list));
		a.add(0, new Rectangle(10, 10));
		assertEquals(1, ListOfListService.countSquares(list));
		d.add(new Rectangle(20, 20));
		assertEquals(2, ListOfListService.countSquares(list));
		c.add((int)(Math.random()*c.size()), new Rectangle(30, 30));
		assertEquals(3, ListOfListService.countSquares(list));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="CountItemsComprehensive", marks=2)
	public void testCountItemsComprehensive() {
		testCountItemsBasic();
		assertEquals(0, ListOfListService.countItems(null));
		assertEquals(18, ListOfListService.countItems(list4_nullItems));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="SumItemsBasic", marks=4)
	public void testSumItemsBasic() {
		assertEquals(0, ListOfListService.sumItems(emptyList));
		assertEquals(2212, ListOfListService.sumItems(listSameSize));
		assertEquals(190, ListOfListService.sumItems(oneRow));
		assertEquals(2278, ListOfListService.sumItems(list1));
		assertEquals(1299, ListOfListService.sumItems(list2));
		assertEquals(378, ListOfListService.sumItems(list3_emptySubLists));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="SumItemsComprehensive", marks=2)
	public void testSumItemsComprehensive() {
		testSumItemsBasic();
		assertEquals(0, ListOfListService.sumItems(null));
		assertEquals(2097, ListOfListService.sumItems(list4_nullItems));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="IsAscendingBasic", marks=4)
	public void testIsAscendingBasic() {
		assertFalse(ListOfListService.isAscending(emptyList, 0));

		assertFalse(ListOfListService.isAscending(oneRow, 0));
		assertFalse(ListOfListService.isAscending(oneRow, 1));
		assertFalse(ListOfListService.isAscending(oneRow, -1));

		assertTrue(ListOfListService.isAscending(list2, 0));
		assertFalse(ListOfListService.isAscending(list2, 1));
		assertFalse(ListOfListService.isAscending(list2, 2));
		assertTrue(ListOfListService.isAscending(list2, 3));
		assertTrue(ListOfListService.isAscending(list2, 4));
		assertTrue(ListOfListService.isAscending(list2, 5));

		list2.get(4).set(1, 20); // 20, 20
		assertTrue(ListOfListService.isAscending(list2, 4));

		assertTrue(ListOfListService.isAscending(list1, 1));

		assertTrue(ListOfListService.isAscending(list3_emptySubLists, 0)); // empty sub-list is ascending
		assertFalse(ListOfListService.isAscending(list3_emptySubLists, 1));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="IsAscendingComprehensive", marks=2)
	public void testIsAscendingComprehensive() {
		testIsAscendingBasic();
		assertFalse(ListOfListService.isAscending(null, 0));

		assertFalse(ListOfListService.isAscending(list4_nullItems, 0));
		assertTrue(ListOfListService.isAscending(list4_nullItems, 2));
		assertFalse(ListOfListService.isAscending(list4_nullItems, 3));
		assertFalse(ListOfListService.isAscending(list4_nullItems, 5));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="AllSubListsAscendingBasic", marks=4)
	public void testAllSubListsAscendingBasic() {
		assertFalse(ListOfListService.allSubListsAscending(listSameSize));
		assertFalse(ListOfListService.allSubListsAscending(oneRow));
		assertTrue(ListOfListService.allSubListsAscending(emptyList));

		assertFalse(ListOfListService.allSubListsAscending(list1));
		assertFalse(ListOfListService.allSubListsAscending(list2));
		assertFalse(ListOfListService.allSubListsAscending(list3_emptySubLists));

		ArrayList<ArrayList<Integer>> ascending = new ArrayList<ArrayList<Integer>>();
		ascending.add(new ArrayList<Integer>(Arrays.asList(10, 20, 70, 90)));
		ascending.add(new ArrayList<Integer>(Arrays.asList(100, 110, 120, 130)));
		ascending.add(new ArrayList<Integer>(Arrays.asList(10, 20, 70, 90)));
		assertTrue(ListOfListService.allSubListsAscending(ascending));
		ascending.add(new ArrayList<Integer>(Arrays.asList(10, 20, 70, 90, 10)));
		assertFalse(ListOfListService.allSubListsAscending(ascending));

		ArrayList<ArrayList<Integer>> ascending2 = new ArrayList<ArrayList<Integer>>();
		ascending2.add(new ArrayList<Integer>(Arrays.asList(10, 20, 70, 90)));
		ascending2.add(new ArrayList<Integer>(Arrays.asList(100, 110, 120, 130)));
		ascending2.add(new ArrayList<Integer>());
		ascending2.add(new ArrayList<Integer>(Arrays.asList(10, 20, 70, 90)));
		assertTrue(ListOfListService.allSubListsAscending(ascending2));
		ascending2.add(new ArrayList<Integer>(Arrays.asList(10, 20, 70, 90, 10)));
		assertFalse(ListOfListService.allSubListsAscending(ascending2));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="AllSubListsAscendingComprehensive", marks=2)
	public void testAllSubListsAscendingComprehensive() {
		testAllSubListsAscendingBasic();
		assertFalse(ListOfListService.allSubListsAscending(null));
		assertFalse(ListOfListService.allSubListsAscending(list4_nullItems));

		ArrayList<ArrayList<Integer>> ascending = new ArrayList<ArrayList<Integer>>();
		ascending.add(new ArrayList<Integer>(Arrays.asList(10, 20, 70, 90)));
		ascending.add(new ArrayList<Integer>(Arrays.asList(100, 110, 120, 130)));
		ascending.add(null);
		ascending.add(new ArrayList<Integer>(Arrays.asList(10, 20, 70, 90)));
		assertFalse(ListOfListService.allSubListsAscending(ascending));

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="AllSubListsSameSizeBasic", marks=4)
	public void testAllSubListsSameSizeBasic() {
		assertTrue(ListOfListService.allSubListsSameSize(listSameSize));
		assertTrue(ListOfListService.allSubListsSameSize(emptyList));
		assertTrue(ListOfListService.allSubListsSameSize(oneRow));
		assertFalse(ListOfListService.allSubListsSameSize(list1));
		assertFalse(ListOfListService.allSubListsSameSize(list2));
		list2.remove(2);
		assertTrue(ListOfListService.allSubListsSameSize(list2));
		assertFalse(ListOfListService.allSubListsSameSize(list3_emptySubLists));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="AllSubListsSameSizeComprehensive", marks=2)
	public void testAllSubListsSameSizeComprehensive() {
		testAllSubListsSameSizeBasic();
		assertFalse(ListOfListService.allSubListsSameSize(null));
		assertFalse(ListOfListService.allSubListsSameSize(list4_nullItems));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="NonNullItemsToListBasic", marks=4)
	public void testNonNullItemsToListBasic() {
		ArrayList<Integer> result = ListOfListService.nonNullItemsToList(emptyList);
		assertEquals("[]", result.toString());

		String copy = listSameSize.toString();
		result = ListOfListService.nonNullItemsToList(listSameSize);
		assertEquals("[10, 70, 20, 90, 100, 700, 200, 900, 9, 8, 7, 6, 20, 22, 24, 26]", result.toString());
		assertEquals(copy, listSameSize.toString());

		copy = oneRow.toString();
		result = ListOfListService.nonNullItemsToList(oneRow);
		assertEquals("[10, 70, 20, 90]", result.toString());
		assertEquals(copy, oneRow.toString());

		copy = list1.toString();
		result = ListOfListService.nonNullItemsToList(list1);
		assertEquals("[9, 8, 7, 6, 5, 4, -1, -2, 100, 200, 700, 900, 10, 70, 20, 90, 30, 80, 20, 22]",
				result.toString());
		assertEquals(copy, list1.toString());

		copy = list2.toString();
		result = ListOfListService.nonNullItemsToList(list2);
		assertEquals("[20, 22, 9, 8, 100, 700, 200, 10, 70, 20, 90, 24, 26]", result.toString());
		assertEquals(copy, list2.toString());

		copy = list3_emptySubLists.toString();
		result = ListOfListService.nonNullItemsToList(list3_emptySubLists);
		assertEquals("[9, 8, 7, 6, 5, 4, -1, -2, 10, 70, 20, 90, 30, 80, 20, 22]", result.toString());
		assertEquals(copy, list3_emptySubLists.toString());
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="NonNullItemsToListComprehensive", marks=2)
	public void testNonNullItemsToListComprehensive() {
		testNonNullItemsToListBasic();
		ArrayList<Integer> result = ListOfListService.nonNullItemsToList(null);
		assertEquals(null, result);

		result = ListOfListService.nonNullItemsToList(list4_nullItems);
		assertEquals("[-1, -2, -1, 4, 5, 6, 7, 8, 9, 100, 200, 700, 900, 10, 20, 90, 20, 22]", result.toString());
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="NonNullItemsToArrayBasic", marks=4)
	public void testNonNullItemsToArrayBasic() {
		int[] result = ListOfListService.nonNullItemsToArray(emptyList);
		assertEquals("[]", Arrays.toString(result));

		result = ListOfListService.nonNullItemsToArray(listSameSize);
		assertEquals("[10, 70, 20, 90, 100, 700, 200, 900, 9, 8, 7, 6, 20, 22, 24, 26]", Arrays.toString(result));

		result = ListOfListService.nonNullItemsToArray(oneRow);
		assertEquals("[10, 70, 20, 90]", Arrays.toString(result));
		result = ListOfListService.nonNullItemsToArray(list1);
		assertEquals("[9, 8, 7, 6, 5, 4, -1, -2, 100, 200, 700, 900, 10, 70, 20, 90, 30, 80, 20, 22]",
				Arrays.toString(result));
		result = ListOfListService.nonNullItemsToArray(list2);
		assertEquals("[20, 22, 9, 8, 100, 700, 200, 10, 70, 20, 90, 24, 26]", Arrays.toString(result));

		result = ListOfListService.nonNullItemsToArray(list3_emptySubLists);
		assertEquals("[9, 8, 7, 6, 5, 4, -1, -2, 10, 70, 20, 90, 30, 80, 20, 22]", Arrays.toString(result));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="NonNullItemsToArrayComprehensive", marks=2)
	public void testNonNullItemsToArrayComprehensive() {
		testNonNullItemsToArrayBasic();
		int[] result = ListOfListService.nonNullItemsToArray(null);
		assertEquals(null, result);

		result = ListOfListService.nonNullItemsToArray(list4_nullItems);
		assertEquals("[-1, -2, -1, 4, 5, 6, 7, 8, 9, 100, 200, 700, 900, 10, 20, 90, 20, 22]", Arrays.toString(result));
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

	@Test @Graded(description="GetClean", marks=4)
	public void testGetClean() {
		ArrayList<ArrayList<Integer>> result = ListOfListService.getClean(null);
		assertFalse(result == null);
		assertTrue(result.isEmpty());

		String copy = listSameSize.toString();
		result = ListOfListService.getClean(listSameSize);
		assertEquals(copy, listSameSize.toString()); // have you modified the original list?
		assertFalse(result == listSameSize); // Ensures result is an instance copy
		assertEquals(result, listSameSize);

		copy = list3_emptySubLists.toString();
		result = ListOfListService.getClean(list3_emptySubLists);
		assertEquals(copy, list3_emptySubLists.toString());
		assertFalse(result == list3_emptySubLists);
		assertEquals(result, list3_emptySubLists);

		copy = list4_nullItems.toString();
		result = ListOfListService.getClean(list4_nullItems);
		assertEquals(copy, list4_nullItems.toString());
		assertEquals("[[-1, -2, -1, 4, 5, 6, 7, 8, 9], [100, 200, 700, 900], [10, 20, 90], [20, 22]]", result.toString());
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}
	
	@AfterEach
	public void logSuccess() throws NoSuchMethodException, SecurityException {
		if(currentMethodName != null && !methodsPassed.contains(currentMethodName)) {
			methodsPassed.add(currentMethodName);
			Method method = getClass().getMethod(currentMethodName);
			Graded graded = method.getAnnotation(Graded.class);
			score+=graded.marks();
			result+=graded.description()+" passed. Marks awarded: "+graded.marks()+"\n";
		}
	}

	@AfterAll
	public static void wrapUp() throws IOException {
		if(result.length() != 0) {
			result = result.substring(0, result.length()-1); //remove the last "\n"
		}
		System.out.println(result+"\nIndicative mark: "+score);
		if(score == 100) {
			System.out.println("♪┛(°.°)┏ You just earned the Margaret Hamilton badge for COMP1010! ♪┏(°.°)┛");
		}
//		String name = "NAME_ME_HERE".replace("./","");
//		String markMessage = name.substring(0, 7)+","+score;
//		System.out.println(markMessage+",\""+result+"\"\n");
//		File file = new File("./reports/"+name.substring(0, 7)+".txt");
//		FileWriter writer = new FileWriter(file);
//		writer.write(markMessage+",\""+result+"\"\n");
//		writer.flush();
//		writer.close();
	}
}
