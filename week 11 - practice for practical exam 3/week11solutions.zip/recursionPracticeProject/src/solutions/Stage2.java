package solutions;

public class Stage2 {
	/**
	 * 
	 * @param n
	 * @return number of digits in n
	 * For example,
	 * 
	 * countDigits(1729) = 4
	 * countDigits(-1729) = 4
	 * countDigits(0) = 0 (That's the termination case)
	 * countDigits(3) = 1
	 * countDigits(8) = 1
	 * countDigits(-43) = 2
	 */
	public static int countDigits(int n) {
		if (n == 0)
			return 0; //to be completed
		if(n < 0)
			n = -n;
		return 1 + countDigits(n/10);
	}
	
	/**
	 * 
	 * @param n
	 * @return the sum of the even digits in n
	 */
	public static int sumEvenDigits(int n) {
		if (n == 0)
			return 0; //to be completed
		if(n < 0)
			n = -n;
		if ((n % 10) % 2 == 0) 
			return n % 10 + sumEvenDigits(n/10);
		return sumEvenDigits(n/10);
	}
	
		
	/**
	 * 
	 * @param n
	 * @param d (a single digit number)
	 * @return the sum of the digits in n that are more than d
	 */
	public static int sumDigitsOver(int n, int d) {
		if (n == 0)
			return 0; //to be completed
		if(n < 0)
			n = -n;
		if ((n % 10) > d)
			return n % 10 + sumDigitsOver(n/10, d);
		return sumDigitsOver(n/10, d);
	}
	
	/**
	 * 
	 * @param n
	 * @param d: digit to count (d >= 0, d <= 9)
	 * @return the number of times digit d exists in integer n
	 * IMPORTANT countDigit(0, d) for any d should return 0
	 * 
	 * countDigit(10074, 0) = 2
	 * countDigit(38, 8) = 1
	 * countDigit(888, 8) = 3
	 * countDigit(12345, 6) = 0
	 * countDigit(0, 0) = 0 (NOT 1)
	 */
	public static int countDigit(int n, int d) {
		if (n == 0)
			return 0; //to be completed
		if(n < 0)
			n = -n;
		if ((n % 10) == d)
			return 1 + countDigit(n/10, d);
		return countDigit(n/10, d);
	}
	
	/**
	 * fibonacci sequence is a sequence where the first two terms
	 * are 0 and 1 and every subsequent term is the sum of the two terms
	 * before it
	 * @param n
	 * @return term at index n in fibonacci sequence
	 * 
	 * FOR EXAMPLE,
	 * fibonacci(0) = 0
	 * fibonacci(1) = 1
	 * fibonacci(3) = 2
	 * fibonacci(6) = 8
	 * fibonacci(8) = 21
	 */
	public static int fibonacci(int n) {
		if (n <= 1)
			return n; //to be completed
		return fibonacci(n - 2) + fibonacci(n - 1);
	}
	
	/**
	 * tribonacci sequence is a variation of fibonacci sequence where the first two terms
	 * are 0, 0 and 1 and every subsequent term is the sum of the THREE terms
	 * before it
	 * @param n
	 * @return term at index n in tribonacci sequence
	 * 
	 * FOR EXAMPLE,
	 * tribonacci(0) = 0
	 * tribonacci(1) = 0
	 * tribonacci(2) = 1
	 * tribonacci(3) = 1
	 * tribonacci(4) = 2
	 * tribonacci(5) = 4
	 * tribonacci(6) = 7
	 * tribonacci(7) = 13
	 */
	public static int tribonacci(int n) {
		if (n < 2) 
			return 0;
		if (n == 2)
			return 1;
		return tribonacci(n - 3) + tribonacci(n - 2) + tribonacci(n - 1);
	}
}