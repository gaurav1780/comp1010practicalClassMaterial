package solutions;

public class Stage3 {
	/**
	 * 
	 * @param str
	 * @return the reverse of the string
	 */
	public static String reverse(String str) {
		if (str == null || str.length() < 2)
			return str;
		return reverse(str.substring(1)) +  str.charAt(0);
	}

	/**
	 * 
	 * @param str
	 * @return true if string is a palindrome (same when reversed), false otherwise
	 */
	public static boolean isPalindrome(String str) {
		if (str == null)
			return false;
		if(str.length() < 2)
			return true; 
		return str.equals(reverse(str));
	}

	/**
	 * 
	 * @param str
	 * @param pattern
	 * @param replacement
	 * @return a modified version of str where all occurrences of pattern
	 * are replaced by replacement
	 * 
	 * For example,
	 * replaceAll("this is better than the other thing", "th", "sup") 
	 * returns the String "supis is better supan supe osuper suping"
	 * 
	 */
	public static String replaceAll(String str, String pattern, String replacement) {
		if (str == null || str.length() < pattern.length())
			return str; //to be completed
		if (str.substring(0, pattern.length()).equals(pattern)) 
			return replacement + replaceAll(str.substring(pattern.length()), pattern, replacement);
		return str.charAt(0) + replaceAll(str.substring(1), pattern, replacement);
	}

	/**
	 * 
	 * @param n
	 * @param d: single digit integer
	 * @return the number of occurrences of digit d in integer n, 
	 * except that a d with another d immediately to its left counts double, 
	 * For example, 
	 * 
	 * if countWeighted(8818, 8) returns 4. 
	 * 
	 * Explanation:
	 * 
	 * First 8 (from left) contributes 1
	 * Second 8 contributes 2 (since there is another 8 immediately to its left)
	 * Third 8 contributes 1
	 * 
	 * Note that mod (%) by 10 yields the rightmost digit (126 % 10 is 6), 
	 * while divide (/) by 10 removes the rightmost digit (126 / 10 is 12).
	 */
	public static int countWeighted(int n, int d) {
		if (n == 0)
			return 0; //to be completed
		if (n % 10 == d) {
			if ((n/10) % 10 == d) 
				return 2 + countWeighted(n/10, d);
			return 1 + countWeighted(n/10, d);
		}
		return countWeighted(n/10, d);
	}

	/**
	 * 
	 * @param str
	 * @param tokens
	 * @return true if str contains all characters from token, false otherwise
	 * Note if tokens contains multiple occurrences of a particular character,
	 * then str must have at least those many occurrences of that character.
	 */
	public static boolean contains(String str, String tokens) {
		if(str == null || tokens == null || tokens.length() > str.length())
			return false;
		if(tokens.isEmpty())
			return true;
		char first = tokens.charAt(0);	
		int idx = str.indexOf(first);
		if(idx < 0)
			return false;
		String restStr = str.substring(0, idx) + str.substring(idx+1); 
		String restTokens = tokens.substring(1);
		return contains(restStr, restTokens);
	}

	/**
	 * two Strings are anagrams of each other if you can rearrange one to form the other one.
	 * @param s1
	 * @param s2
	 * @return true if s1 and s2 are anagrams of each other, false otherwise
	 */
	public static boolean areAnagrams(String s1, String s2) {
		return s1.length() == s2.length() && Stage3.contains(s1,s2);
	}

	private static String[] morseCodes = {"-","-...","-.-.","-..",".",
			"..-.","--.","....","..",".---",
			"-.-",".-..","--","-.","---",
			".--.","--.-",".-.","...","-",
			"..-","...-",".--","-..-",
			"-.--","--.."};

	/**
	 * @param message
	 * @return a String containing morse code for message passed.
	 * IMPORTANT lookup array provided as static variable morseCodes
	 * Use / as a space
	 * Use space to separate morse codes for two letters
	 * For example, 
	 * if message = "nice one", return "-. .. -.-. . / --- -. . "
	 */
	public static String getMorse(String message) {
		//morseCodes[i] gives the equivalent morse code for letter (char)('a' + i)
		//'b' -> morseCodes[1]
		//'k' ('a' + 10) -> morseCodes[10]
		if(message == null)
			return null;
		message = message.toLowerCase();
		if (message == null || message.isEmpty())
			return message; //to be completed
		if(message.charAt(0) == ' ')
			return "/ " + getMorse(message.substring(1));
		return morseCodes[message.charAt(0) - 'a'] + ' ' + getMorse(message.substring(1));
	}
}