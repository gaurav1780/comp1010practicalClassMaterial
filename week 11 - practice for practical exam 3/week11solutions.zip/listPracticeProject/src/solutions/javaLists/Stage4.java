package solutions.javaLists;

import java.util.*;

public class Stage4 {
	/**
	 * sort the list in ascending order
	 * @param list
	 */
	public static void sort(ArrayList<Integer> list) {
		if (list != null) {
			for (int i = 0; i < list.size() - 1; i++) {
				for (int j = i + 1; j < list.size(); j++) {
					if (list.get(i) > list.get(j)) {
						int temp = list.get(i);
						list.set(i, list.get(j));
						list.set(j, temp);
					}
				}
			}
		} //to be completed
	}

	/**
	 * sort the list in ascending order if asc is true, descending order if asc is false
	 * @param list
	 * @param asc (true if ascending, false if descending)
	 */
	public static void sort(ArrayList<Integer> list, boolean asc) {
		if (list != null) {
			if (asc) 
				sort(list);//to be completed
			else {
				for (int i = 0; i < list.size() - 1; i++) {
					for (int j = i + 1; j < list.size(); j++) {
						if (list.get(i) < list.get(j)) {
							int temp = list.get(i);
							list.set(i, list.get(j));
							list.set(j, temp);
						}
					}
				}
			}
		} //to be completed
	}

	/**  
	 * @param a: if not null, assumed to be sorted in ascending order
	 * @param b: if not null, assumed to be sorted in ascending order
	 * @return result of merging a and b and maintaining an overall sorted order
	 * return null if EITHER of the parameter lists are null
	 */
	public static ArrayList<Integer> merge(ArrayList<Integer> a, ArrayList<Integer> b) {
		if (a == null || b == null)
			return null;
		ArrayList<Integer> result = new ArrayList<Integer>();
		int idx1 = 0, idx2 = 0;
		while(idx1 < a.size() && idx2 < b.size()) {
			if(a.get(idx1) < b.get(idx2)) { 
				result.add(a.get(idx1));
				idx1++;
			}
			else {
				result.add(b.get(idx2));
				idx2++;
			}
		}

		while(idx1 < a.size()) {
			result.add(a.get(idx1));
			idx1++;
		}

		while(idx2 < b.size()) {
			result.add(b.get(idx2));
			idx2++;
		}

		return result;
	}

	/**
	 * 
	 * @param list
	 * @return the longest sequence of consecutive items that are in ascending order.
	 * return null if list is null
	 */
	public static ArrayList<Integer> getLongestAscendingRun(ArrayList<Integer> list) {
		if (list == null)
			return null;
		if (list.isEmpty()) 
			return new ArrayList<Integer>();
		int start = 0;
		int size = 1;
		int maxSize = 1;
		for (int i = 1; i < list.size(); i++) {
			if (list.get(i) >= list.get(i - 1)) {
				size++;
			} else if (maxSize < size) {
				maxSize = size;
				size = 1;
				start = i - maxSize;
			}
		}
		if (maxSize < size) {
			maxSize = size;
			start = list.size() - size;
		}
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (int i = start; i < start + maxSize; i++) {
			result.add(list.get(i));
		}
		return result;  //to be completed
	}

	/**
	 * 
	 * @param a
	 * @param b
	 * @return items that occur in both the lists.
	 * the order of items in the reversed list should be in the order they occur in the first list.
	 * also, there should be a single instance of each item in the resulting list.
	 * 
	 * For example:
	 * a = [1,4,3,6,2,1,2,7,3,2,8,7,7]
	 * b = [7,7,7,7,4,4,5,5,5,5,1,1,1,7,1,1,1,1,1,2]
	 * return [1,4,2,7]
	 * 
	 * return null if either list is null
	 */
	public static ArrayList<Integer> getIntersection(ArrayList<Integer> a, ArrayList<Integer> b) {
		if (a == null || b == null) 
			return null;
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (int i = 0; i < a.size(); i++) {
			int temp = a.get(i);
			if (i == a.lastIndexOf(temp)) {
				if (b.contains(temp)) {
					result.add(temp);
				}
			}
		}
		return result; //to be completed
	}

	/**
	 * a modified version of getIntersection
	 * 
	 * @param a
	 * @param b
	 * @return items that occur in both the lists.
	 * the order of items in the reversed list should be in the order they occur in the first list.
	 * the number of times an item exists in the resulting list is the smaller of the occurrences
	 * of that item in a and b
	 * 
	 * For example:
	 * a = [1,4,3,6,2,1,2,7,3,2,8,7,7]
	 * b = [4,4,5,5,5,5,1,1,1,7,1,1,1,1,1,2,7]
	 * return [1,4,2,1,7,7]
	 * 
	 * return null if either list is null
	 */
	public static ArrayList<Integer> getIntersectionV2(ArrayList<Integer> a, ArrayList<Integer> b) {
		if (a == null || b == null) 
			return null;
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (int i = 0; i < a.size(); i++) {
			int temp = a.get(i);
			if (b.contains(temp)) {
				result.add(temp);
			}
		}
		for (int i = 0; i < result.size(); i++) {
			int temp = result.get(i);
			if (count(result, temp) > Math.min(count(a, temp), count(b, temp))) {
				result.remove(i);
				i--;
			}
		}
		return result; //to be completed
	}

	public static int count(ArrayList<Integer> list, int temp) {
		int c = 0;
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i) == temp) {
				c++;
			}
		}
		return c;
	}

	/**
	 * @param list: an ArrayList of ArrayLists
	 * @param n: assume n > 0
	 * @return: a list containing items that exist in at least
	 * n (sub)ArrayList of the passed list
	 * order of items should be -
	 * all items from the first sub-list that satisfy the requirement, followed by,
	 * all items from the second sub-list (but not in the first sub-list) that satisfy the 
	 * requirement, followed by,
	 * all items from the third sub-list (but not in the first two sub-lists) that satisfy 
	 * the requirement, and so on...
	 * for example, 
	 * if list = [[1,2,3,4,5], [4,6,7,8], [3,5,7,6]] and n = 2, return the list [3,4,5,6,7]
	 * if list = [[1,2,3,4,5], [4,6,7,8], [3,5,7,6]] and n = 3, return the list []
	 * if list = [[1,2,3,4,5,6], [4,6,7,8], [3,5,7,6,4]] and n = 3, return the list [4, 6]
	 */
	public static ArrayList<Integer> itemsInAtleastN(ArrayList<ArrayList<Integer>> list, int n) {
		if (list == null)
			return null; //to be completed
		ArrayList<Integer> result = new ArrayList<Integer>();
		for(int i=0; i < list.size(); i++) { 
			if(list.get(i) == null) 
				continue;
			for(int k=0; k < list.get(i).size(); k++) { 
				int count = 1;
				for(int p=0; p < list.size(); p++) {
					if(list.get(p) == null || i == p)
						continue;
					if(list.get(p).contains(list.get(i).get(k))) {
						count++;
						if(count >= n)
							break; //exit innermost loop
					}
				}
				if(count >= n && !result.contains(list.get(i).get(k))) 
					result.add(list.get(i).get(k)); 
			}
		}
		return result;
	}
}
