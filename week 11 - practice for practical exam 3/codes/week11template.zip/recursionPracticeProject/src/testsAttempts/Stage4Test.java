package testsAttempts;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import attempts.Stage1;
import attempts.Stage2;
import attempts.Stage4;

class Stage4Test {

	@Test
	void testBinarySearch() {
		int[] a = {10,10,10,10,10,10};
		assertTrue(Stage4.binarySearch(a, 10, 0, a.length-1) >= 0);
		assertEquals(-1, Stage4.binarySearch(a, 20, 0, a.length-1));
		
		a = new int[]{10,20,30,40,50,60,70,80,80,80,80,80,90};

		assertTrue(Stage4.binarySearch(a, 10, 0, a.length-1) >= 0);
		assertTrue(Stage4.binarySearch(a, 10, 0, a.length-1) < a.length);
		assertEquals(10, a[Stage4.binarySearch(a, 10, 0, a.length-1)]);
		
		assertTrue(Stage4.binarySearch(a, 80, 0, a.length-1) >= 0);
		assertTrue(Stage4.binarySearch(a, 80, 0, a.length-1) < a.length);
		assertEquals(80, a[Stage4.binarySearch(a, 80, 0, a.length-1)]);
	
		assertEquals(-1, Stage4.binarySearch(a, 100, 0, a.length-1));
	}

	@Test
	void testFastPower() {
		assertEquals(4, Stage4.fastPower(2, 2));	
		assertEquals(4, Stage4.fastPower(-2, 2));	
		assertEquals(8, Stage4.fastPower(2, 3));	
		assertEquals(-8, Stage4.fastPower(-2, 3));	
		assertEquals(1, Stage4.fastPower(4, 0));	
		assertEquals(6561, Stage4.fastPower(3, 8));	
	}

	@Test
	void testFastFibonacci() {
		assertEquals(0, Stage4.fastFibonacci(0));
		assertEquals(1, Stage4.fastFibonacci(1));
		assertEquals(5, Stage4.fastFibonacci(5));
		assertEquals(8, Stage4.fastFibonacci(6));
		assertEquals(21, Stage4.fastFibonacci(8));
	}

	@Test
	void testGetPermutation() {
		assertNull(Stage4.getPermutation(5, 0));
		assertNull(Stage4.getPermutation(5, 120));
		
		assertNotNull(Stage4.getPermutation(5, 0));
		assertEquals("12345", Stage4.getPermutation(5, 0));

		assertNotNull(Stage4.getPermutation(5, 7));
		assertEquals("21345", Stage4.getPermutation(5, 7));

		assertNotNull(Stage4.getPermutation(5, 119));
		assertEquals("54321", Stage4.getPermutation(5, 119));

		assertNotNull(Stage4.getPermutation(9, 0));
		assertEquals("123456789", Stage4.getPermutation(9, 0));
	}

	@Test
	void testSplit53() {
		assertTrue(Stage4.split53(new int[] {1, 1}));
		assertTrue(Stage4.split53(new int[] {2, 4, 2}));
		assertTrue(Stage4.split53(new int[] {3, 3, 5, 1}));
		assertTrue(Stage4.split53(new int[] {3, 5, 6, 10, 3, 3}));

		assertFalse(Stage4.split53(new int[] {3, 5, 8}));
		assertFalse(Stage4.split53(new int[] {2, 2, 2, 1}));
		assertFalse(Stage4.split53(new int[] {5,5,5, 5, 3,3,3,3,3})); //extra 5
	}

}
