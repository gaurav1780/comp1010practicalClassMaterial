package testsAttempts;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import attempts.Stage1;

class Stage1Test {

	@Test
	void testSum() {
		assertEquals(0, Stage1.sum(0));
		assertEquals(0, Stage1.sum(-5));
		assertEquals(6, Stage1.sum(3));	
	}

	@Test
	void testProduct() {
		assertEquals(1, Stage1.product(0));
		assertEquals(1, Stage1.product(-5));
		assertEquals(120, Stage1.product(5));	
	}

	@Test
	void testSumSquares() {
		assertEquals(0, Stage1.sumSquares(0));
		assertEquals(0, Stage1.sumSquares(-5));
		assertEquals(14, Stage1.sumSquares(3));	
	}

	@Test
	void testSumEven() {
		assertEquals(0, Stage1.sumEven(0));
		assertEquals(0, Stage1.sumEven(-5));
		assertEquals(2, Stage1.sumEven(3));	
		assertEquals(6, Stage1.sumEven(4));	
	}

	@Test
	void testSumOdd() {
		assertEquals(0, Stage1.sumOdd(0));
		assertEquals(0, Stage1.sumOdd(-5));
		assertEquals(4, Stage1.sumOdd(3));	
		assertEquals(4, Stage1.sumOdd(4));	
		assertEquals(9, Stage1.sumOdd(5));	
	}

	@Test
	void testPower() {
		assertEquals(4, Stage1.power(2, 2));	
		assertEquals(4, Stage1.power(-2, 2));	
		assertEquals(8, Stage1.power(2, 3));	
		assertEquals(-8, Stage1.power(-2, 3));	
		assertEquals(1, Stage1.power(4, 0));	
		assertEquals(6561, Stage1.power(3, 8));	
	}

	@Test
	void testPowerV2() {
		assertEquals(4, Stage1.power(2, 2));	
		assertEquals(4, Stage1.power(-2, 2));	
		assertEquals(8, Stage1.power(2, 3));	
		assertEquals(-8, Stage1.power(-2, 3));	
		assertEquals(1, Stage1.power(4, 0));	
		assertEquals(6561, Stage1.power(3, 8));	
	}

}
