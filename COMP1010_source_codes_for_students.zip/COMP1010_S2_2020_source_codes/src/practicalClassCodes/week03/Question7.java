package practicalClassCodes.week03;
import static org.junit.Assert.*;
import org.junit.*;

import java.io.*;
import java.text.*;
import java.util.*;

public class Question7 {
	/**
	 * return the first index at which target exists in the array.
	 * return -1 if target does not exist in the array
	 */
	public static int indexOf(int[] data, int target) {
		return 0; //to be completed
	}

	@Test
	public void testIndexOf() {
		//add test cases
	}
}
