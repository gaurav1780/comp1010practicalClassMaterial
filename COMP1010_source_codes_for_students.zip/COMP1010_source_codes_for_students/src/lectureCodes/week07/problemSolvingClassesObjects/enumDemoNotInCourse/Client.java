package lectureCodes.week07.problemSolvingClassesObjects.enumDemoNotInCourse;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Day myDay = Day.SATURDAY;
		System.out.println(myDay);
	}

}
