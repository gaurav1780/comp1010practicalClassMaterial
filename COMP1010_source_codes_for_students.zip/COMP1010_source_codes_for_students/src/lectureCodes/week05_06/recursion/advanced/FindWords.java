package lectureCodes.week05_06.recursion.advanced;

public class FindWords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("z".compareTo("abcd"));
	}

}
