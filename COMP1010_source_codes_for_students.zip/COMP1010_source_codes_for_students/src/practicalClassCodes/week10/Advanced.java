package practicalClassCodes.week10;

import java.util.*;

public class Advanced {
	public static ArrayList<Integer> getUniqueValues(ArrayList<ArrayList<Integer>> list) {
		return null; //to be completed
	}

	public static ArrayList<Integer> getItemsUniqueToSubLists(ArrayList<ArrayList<Integer>> list) {
		return null; //to be completed
	}

	public static ArrayList<Integer> longestRepeatingSequence(ArrayList<Integer> list) {
		return null; //to be completed
	}
}
