package week12practicePackage;

import java.util.ArrayList;

//DO NOT MODIFY Node class
class Node {
	public int data;
	public Node next;
	
	public Node(int d, Node n) {
		data = d;
		next = n;
	}
}

public class Week12 {
	//RECURSION QUESTIONS (4)
	
	/**
	 * 
	 * @param n 
	 * @return sum of the first n positive integers (1+2+...+n)
	 * return 0 if n<=0
	 */
	public static int sum(int n) {
		return 0; //to be completed
	}

	/**
	 * 
	 * @param n 
	 * @return sum of the squares of the first n positive integers 
	 * (1*1 + 2*2 + ... + n*n)
	 * return 0 if n<=0
	 */
	public static int sumSquares(int n) {
		return 0; //to be completed
	}


	/**
	 * 
	 * @param n
	 * @return the sum of the even digits in n
	 */
	public static int sumEvenDigits(int n) {
		return 0; //to be completed
	}

	/**
	 * 
	 * @param str
	 * @return the reverse of the string
	 * return null if string is null
	 */
	public static String reverse(String str) {
		return null; //to be completed
	}

	//BUILT-IN ARRAYLIST CLASS QUESTIONS (6)
	
	/**
	 * 
	 * @param list
	 * @return the sum of the first and last items
	 * return null if list is null or empty
	 * return the only value if list contains a single item
	 */
	public static Integer getSumFirstLastItems(ArrayList<Integer> list) {
		return null; //to be completed
	}

	/**
	 * 
	 * @param a
	 * @param b
	 * @return true if the two lists are of the same size, false otherwise
	 * return false if EITHER list is null
	 */
	public static boolean sameSize(ArrayList<Integer> a, ArrayList<Integer> b) {
		return false; //to be completed
	}

	/**
	 * 
	 * @param list
	 * @return the sum of all negatives items of the list
	 * return 0 if list is null or empty
	 */
	public static int sumNegatives(ArrayList<Integer> list) {
		return 0; //to be completed
	}

	/**
	 * 
	 * @param list
	 * @param low
	 * @param high (assume low <= high)
	 * @return the number of items in the list that belong to the range [low ... high]
	 * return 0 if list is null or empty
	 */
	public static int countInRange(ArrayList<Integer> list, int low, int high) {
		return 0; //to be completed
	}

	/**
	 * 
	 * @param list
	 * @param low
	 * @param high (assume low <= high)
	 * @return true if all the items in the list are in the range [low ... high]
	 * return false if list is null
	 * return true if the list is empty
	 */
	public static boolean allInRange(ArrayList<Integer> list, int low, int high) {
		return false; //to be completed
	}

	/**
	 * 
	 * @param list
	 * @return true if the list is in ascending order.
	 * that is, if every item is less than or equal to the next item.
	 * return false if list is null
	 * return true if list is empty or contains one item
	 */
	public static boolean isAscending(ArrayList<Integer> list) {
		return false; //to be completed
	}
	
	//RECURSIVE DATA STRUCTURES (NODE) QUESTIONS (3)
	
	/**
	 * 
	 * @param start
	 * @return sum of all even values in nodes starting at node start
	 */
	public static int sumEven(Node start) {
		return 0; //to be completed
	}
	
	/**
	 * 
	 * @param start
	 * @return true if any node, starting at node start, contain a positive value, false otherwise
	 * return false if start is null
	 */
	public static boolean containsPositive(Node start) {
		return false; //to be completed
	}
	
	/**
	 * 
	 * @param start
	 * @return true if all nodes, starting at node start, contain a non-zero value, false otherwise
	 * return true if start is null
	 */
	public static boolean allNonZeroes(Node start) {
		return false; //to be completed
	}
	
	//ARRAY OF OBJECTS QUESTIONS (2)
	
	/**
	 * 
	 * @param dates
	 * @param month (a value between 1 and 12)
	 * @return number of Date objects in the array dates that occur in given month
	 */
	public static int countDatesInMonth(Date[] dates, int month) {
		return 0; //to be completed
	}
	
	/**
	 * 
	 * @param dates
	 * @return true if two (or more) Date objects in the array are the same.
	 * Think about which method can you call on Date objects for these.
	 */
	public static boolean twoSameDates(Date[] dates) {
		return false; //to be completed
	}
}

//CUSTOM-BUILT ARRAYLIST QUESTION (1)

class CustomArrayList {
	public int[] data; //data.length gives the capacity
	public int nItems; //nItems gives items currently in the arraylist

	public CustomArrayList() {
		data = new int[5];
		nItems = 0;
	}
	
	//DO NOT MODIFY
	public void add(int val) {
		if(nItems == data.length) {
			grow();
		}
		data[nItems++] = val;
	}
	
	/**
	 * increase the size of the resident array data by 3
	 */
	public void grow() {
		//to be completed
	}
}

//CUSTOM-BUILT LINKEDLIST QUESTIONS (3)

class CustomLinkedList {
	Node head;
	
	//DO NOT MODIFY
	public void addToFront(int val) {
		head = new Node(val, head);
	}
	
	/**
	 * 
	 * @return the number of nodes in the list (starting at head)
	 */
	public int size() {
		return 0; //to be completed
	}
	
	/**
	 * 
	 * @param val
	 * @return true if any node, starting at head, contains the value val, false otherwise
	 * return false if head is null
	 */
	public boolean contains(int val) {
		return false; //to be completed
	}
	
		/**
	 * 
	 * @param val
	 * @return index at which val exists (return 0 if val exists at head, 1 if val exists at node after head and so on).
	 * return -1 if val doesn't exist at any node starting at head
	 */
	public int indexOf(int val) {
		return -1; //to be completed
	}
}
