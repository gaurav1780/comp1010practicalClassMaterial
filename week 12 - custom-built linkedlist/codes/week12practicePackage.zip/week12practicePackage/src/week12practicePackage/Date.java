package week12practicePackage;
public class Date {
	public int day, month, year;

	public Date(String str) {
		String[] tokens = str.split("/");
		month = Integer.parseInt(tokens[1]);
		day = Integer.parseInt(tokens[0]);
		year = Integer.parseInt(tokens[2]);
	}

	public String toString() {
		return day+"/"+month+"/"+year;
	}

	public int compareTo(Date other) {
		if(year > other.year)
			return 1;
		if(year < other.year)
			return -1;
		if(month > other.month)
			return 1;
		if(month < other.month)
			return -1;
		if(day > other.day)
			return 1;
		if(day < other.day)
			return -1;
		return 0;
	}
}
