package week12practicePackage;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Week12Test {
	private ArrayList<Integer> nullList, emptyList, singleItemList, list1, list2;

	@BeforeEach
	public void run() {
		nullList = null;
		emptyList = new ArrayList<Integer>();
		singleItemList = new ArrayList<Integer>(Arrays.asList(-7));
		list1 = new ArrayList<Integer>(Arrays.asList(10,70,20,90));
		list2 = new ArrayList<Integer>(Arrays.asList(-5, 0, 8, -7, 9, 15, 23, -1, 5));
	}

	@Test
	public void testSum() {
		assertEquals(0, Week12.sum(0));
		assertEquals(0, Week12.sum(-5));
		assertEquals(6, Week12.sum(3));	
	}


	@Test
	public void testSumSquares() {
		assertEquals(0, Week12.sumSquares(0));
		assertEquals(0, Week12.sumSquares(-5));
		assertEquals(14, Week12.sumSquares(3));	
	}

	@Test
	public void testSumEvenDigits() {
		assertEquals(2, Week12.sumEvenDigits(1729));
		assertEquals(2, Week12.sumEvenDigits(-1729));
		assertEquals(0, Week12.sumEvenDigits(1739));
		assertEquals(0, Week12.sumEvenDigits(-1739));
		assertEquals(20, Week12.sumEvenDigits(80264));
		assertEquals(20, Week12.sumEvenDigits(-80264));
	}

	@Test
	public void testReverse() {
		assertNull(Week12.reverse(null));

		assertNotNull(Week12.reverse(""));
		assertEquals("", Week12.reverse(""));

		assertNotNull(Week12.reverse("super"));
		assertEquals("repus", Week12.reverse("super"));
	}



	@Test
	public void testGetSumFirstLastItems() {
		assertEquals(null, Week12.getSumFirstLastItems(nullList));
		assertEquals(null, Week12.getSumFirstLastItems(emptyList));
		assertEquals((Integer)(-7), Week12.getSumFirstLastItems(singleItemList));
		assertEquals((Integer)(100), Week12.getSumFirstLastItems(list1));
		assertEquals((Integer)(0), Week12.getSumFirstLastItems(list2));
	}

	@Test
	public void testSameSize() {
		ArrayList<Integer> list3 = new ArrayList<Integer>(Arrays.asList(1,2,3,4));
		assertTrue(Week12.sameSize(list1, list3));
		list3.add(10); //list3 now contains 5 items
		assertFalse(Week12.sameSize(list1, list3));
		list3.remove(0); //list3 now contains 4 items
		assertTrue(Week12.sameSize(list1, list3));
		list3.remove(0); //list3 now contains 3 items
		assertFalse(Week12.sameSize(list1, list3));
	}


	@Test
	public void testSumNegatives() {
		assertEquals(0, Week12.sumNegatives(nullList));
		assertEquals(0, Week12.sumNegatives(emptyList));
		assertEquals(-7, Week12.sumNegatives(singleItemList));
		assertEquals(0, Week12.sumNegatives(list1));
		assertEquals(-13, Week12.sumNegatives(list2));
	}

	@Test
	public void testCountInRange() {
		assertEquals(0, Week12.countInRange(nullList,0,5));
		assertEquals(0, Week12.countInRange(emptyList,0,5));
		assertEquals(0, Week12.countInRange(singleItemList,-6,6));
		assertEquals(1, Week12.countInRange(singleItemList,-7,6));
		assertEquals(0, Week12.countInRange(singleItemList,-10,-8));
		assertEquals(1, Week12.countInRange(singleItemList,-10,-7));
		assertEquals(4, Week12.countInRange(list1,10,90));
		assertEquals(3, Week12.countInRange(list1,20,90));
		assertEquals(3, Week12.countInRange(list1,10,75));
		assertEquals(list2.size(), Week12.countInRange(list2,-10000, 10000));
	}

	@Test
	public void testAllInRange() {
		assertFalse(Week12.allInRange(nullList,0,5));
		//assertFalse(Week12.allInRange(emptyList,0,5));
		assertFalse(Week12.allInRange(singleItemList,-6,0));
		assertTrue(Week12.allInRange(singleItemList,-7,0));
		assertFalse(Week12.allInRange(singleItemList,-10,-8));
		assertTrue(Week12.allInRange(singleItemList,-10,-7));
		assertFalse(Week12.allInRange(list1,0,10));
		assertFalse(Week12.allInRange(list1,20,100));
		assertTrue(Week12.allInRange(list1,10,90));
		assertFalse(Week12.allInRange(list1,0,9));
		assertFalse(Week12.allInRange(list2,-6,23));
		assertFalse(Week12.allInRange(list2,-7,22));
		assertTrue(Week12.allInRange(list2,-7,23));
	}

	@Test
	public void testIsAscending() {
		assertFalse(Week12.isAscending(nullList));
		assertTrue(Week12.isAscending(emptyList));
		assertTrue(Week12.isAscending(singleItemList));
		assertFalse(Week12.isAscending(list1));
		assertFalse(Week12.isAscending(list2));
		list1 = new ArrayList<Integer>(Arrays.asList(10,70,70,90));
		assertTrue(Week12.isAscending(list1));
		list1 = new ArrayList<Integer>(Arrays.asList(10,70,70,60));
		assertFalse(Week12.isAscending(list1));
	}

	@Test
	public void testSumEven() {
		Node d = new Node(-2, null);
		Node c = new Node(0, d);
		Node b = new Node(40, c);
		Node a = new Node(7, b);
		assertEquals(0, Week12.sumEven(null));
		assertEquals(38, Week12.sumEven(a));
		assertEquals(-2, Week12.sumEven(c));
	}

	@Test
	public void testContainsPositive() {
		Node d = new Node(-2, null);
		Node c = new Node(0, d);
		Node b = new Node(40, c);
		Node a = new Node(7, b);
		assertFalse(Week12.containsPositive(null));
		assertTrue(Week12.containsPositive(a));
		assertFalse(Week12.containsPositive(d));
		assertFalse(Week12.containsPositive(c));
	}

	@Test
	public void testAllNonZeroes() {
		Node d = new Node(-2, null);
		Node c = new Node(0, d);
		Node b = new Node(40, c);
		Node a = new Node(7, b);
		assertTrue(Week12.allNonZeroes(null));
		assertFalse(Week12.allNonZeroes(a));
		assertTrue(Week12.allNonZeroes(d));
	}

	@Test
	public void testCountDatesInMonth() {
		assertEquals(0, Week12.countDatesInMonth(null, 1));
		Date[] dates = new Date[5];
		dates[0] = new Date("13/4/2011");
		dates[1] = new Date("19/4/2014");
		dates[2] = new Date("15/8/1956");
		dates[3] = new Date("25/11/1980");
		dates[4] = new Date("15/4/2007");
		assertEquals(3,  Week12.countDatesInMonth(dates, 4));
		assertEquals(1,  Week12.countDatesInMonth(dates, 11));
		assertEquals(1,  Week12.countDatesInMonth(dates, 8));
		assertEquals(0,  Week12.countDatesInMonth(dates, 12));
	}

	@Test
	public void testTwoSameDates() {
		assertFalse(Week12.twoSameDates(null));
		Date[] dates = new Date[5];
		dates[0] = new Date("13/4/2011");
		dates[1] = new Date("19/4/2014");
		dates[2] = new Date("15/8/1956");
		dates[3] = new Date("25/11/1980");
		dates[4] = new Date("15/4/2007");
		assertFalse(Week12.twoSameDates(dates));

		dates[3] = new Date("13/4/2011"); //now first and fourth dates are the same
		assertTrue(Week12.twoSameDates(dates));

		dates[3] = new Date("25/11/1980"); //back to all being different
		assertFalse(Week12.twoSameDates(dates));

		dates[3] = new Date("15/4/2007"); //now fourth and fifth dates are the same
		assertTrue(Week12.twoSameDates(dates));

		dates[3] = new Date("19/4/2011"); //back to all being different
		assertFalse(Week12.twoSameDates(dates));
	}

	@Test
	public void testGrow() {
		CustomArrayList list = new CustomArrayList();
		list.add(10);
		list.add(70);
		list.add(20);
		list.add(90);

		assertEquals(4, list.nItems);
		assertEquals(5, list.data.length);
		assertEquals("[10, 70, 20, 90, 0]", Arrays.toString(list.data)); 

		list.grow();
		assertEquals(4, list.nItems);
		assertEquals(8, list.data.length);
		assertEquals("[10, 70, 20, 90, 0, 0, 0, 0]", Arrays.toString(list.data)); 
	}

	@Test
	public void testSize() {
		CustomLinkedList list = new CustomLinkedList();
		assertEquals(0, list.size());
		list.addToFront(90);
		list.addToFront(20);
		list.addToFront(70);
		list.addToFront(10);
		assertEquals(4, list.size());	
	}

	@Test
	public void testContains() {
		CustomLinkedList list = new CustomLinkedList();
		assertFalse(list.contains(10));
		list.addToFront(90);
		list.addToFront(20);
		list.addToFront(70);
		list.addToFront(10);
		assertTrue(list.contains(10));
		assertTrue(list.contains(70));
		assertTrue(list.contains(20));
		assertTrue(list.contains(90));
		assertFalse(list.contains(80));
		assertFalse(list.contains(30));
	}

	@Test
	public void testIndexOf() {
		CustomLinkedList list = new CustomLinkedList();
		assertEquals(-1, list.indexOf(10));
		list.addToFront(10);
		list.addToFront(70);
		list.addToFront(10);
		list.addToFront(70); //list is now [70, 10, 70, 10]
		assertEquals(1, list.indexOf(10));
		assertEquals(0, list.indexOf(70));
		assertEquals(-1, list.indexOf(30));
		assertEquals(-1, list.indexOf(80));
	}
}
